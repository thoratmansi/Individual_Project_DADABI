SELECT
  YEAR([CREATION DATE]) AS Year,
  COUNT([CASE ID]) AS TotalRequests
FROM
   callcenter
WHERE
  YEAR([CREATION DATE]) BETWEEN 2018 AND 2021
GROUP BY
  YEAR([CREATION DATE])
ORDER BY
  Year;
GO-- Question 1


SELECT
  CONCAT(YEAR([CREATION DATE]), '-', MONTH([CREATION DATE])) AS YearMonth,
  COUNT([CASE ID]) AS TotalRequests
FROM
  callcenter
WHERE
  YEAR([CREATION DATE]) BETWEEN 2018 AND 2021
GROUP BY
  [CREATION DATE]
ORDER BY
  [CREATION DATE];
GO---- Question 2

SELECT
  SOURCE,
  COUNT([CASE ID]) AS TotalRequests
FROM
  callcenter
GROUP BY
  SOURCE
ORDER BY
  TotalRequests DESC;
go -- question 3

SELECT
  DEPARTMENT,
  YEAR([CREATION DATE]) AS Year,
  COUNT([CASE ID]) AS TotalRequests
FROM
  callcenter
GROUP BY
  Department, YEAR([CREATION DATE])
ORDER BY
  Department, Year([CREATION DATE]);
go ---- Question 4

SELECT TOP 10
  [CASE ID],
  CATEGORY1,
  Type,
  [DAYS TO CLOSE] AS ResponseTime
FROM
  callcenter
WHERE
  [DAYS TO CLOSE] IS NOT NULL
ORDER BY
  ResponseTime ASC;
go --question 5



SELECT TOP 10
  NEIGHBORHOOD AS Area, 
  COUNT([CASE ID]) AS TotalRequests
FROM
  callcenter
GROUP BY
  NEIGHBORHOOD
ORDER BY
  TotalRequests DESC;
go -- question 6




SELECT
  DEPARTMENT,
  [WORK GROUP],
  COUNT([CASE ID]) AS TotalRequests
FROM
  callcenter
GROUP BY
  DEPARTMENT, [WORK GROUP]
ORDER BY
  DEPARTMENT, TotalRequests DESC;
go -- question 7



SELECT
  DEPARTMENT,
  DATEDIFF(day, [CREATION DATE], [CLOSED DATE]) AS ResponseTime
FROM
  callcenter;
go -- question 8




SELECT
  YEAR([CREATION DATE]) AS Year,
  Status,
  COUNT([CASE ID]) AS TotalRequests
FROM
  callcenter
WHERE
  YEAR([CREATION DATE]) BETWEEN 2018 AND 2021
GROUP BY
  YEAR([CREATION DATE]), Status;
go -- question 9




SELECT
  CATEGORY1,
  AVG([DAYS TO CLOSE]) AS AverageDaysToClose
FROM
  callcenter
GROUP BY
  Category1
ORDER BY
  AverageDaysToClose DESC;
go -- question 10 A


 SELECT Department,
  COUNT([CASE ID]) AS TotalRequests
FROM
  callcenter	
GROUP BY
  Department;
go -- question 10 B
